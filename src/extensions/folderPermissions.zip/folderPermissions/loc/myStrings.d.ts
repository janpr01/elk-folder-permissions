declare interface IFolderPermissionsCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'FolderPermissionsCommandSetStrings' {
  const strings: IFolderPermissionsCommandSetStrings;
  export = strings;
}

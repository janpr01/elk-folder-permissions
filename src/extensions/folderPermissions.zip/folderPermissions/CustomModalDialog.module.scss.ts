/* tslint:disable */
require("./CustomModalDialog.module.css");
const styles = {
  overlay: 'overlay_0d86a480'
};

export default styles;
/* tslint:enable */